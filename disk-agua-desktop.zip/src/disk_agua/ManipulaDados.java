/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package disk_agua;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.LinkedList;

public class ManipulaDados {
    public static void salvaArquivo(LinkedList<Agua> f){
        FileOutputStream arquivo;
        try {
            arquivo = new FileOutputStream("estoqueAgua.txt");
            ObjectOutputStream obj = new ObjectOutputStream(arquivo);
            obj.writeObject(f);
            obj.flush();
        } catch (Exception ex) {
            System.out.println("erro ao salvar em arquivo");
        }
    }

    public static LinkedList<Agua> leArquivo(){
        FileInputStream arquivo;
        LinkedList<Agua> estoqueAgua = null;
        try {
            arquivo = new FileInputStream("estoqueAgua.txt");
            ObjectInputStream obj = new ObjectInputStream(arquivo);
            estoqueAgua = (LinkedList<Agua>) obj.readObject();
        } catch (Exception ex){
            System.out.println("erro ao ler em arquivo");
        }
        return estoqueAgua; 
    }
}
