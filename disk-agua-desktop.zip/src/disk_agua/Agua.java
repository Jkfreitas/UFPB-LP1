
package disk_agua;

import java.io.Serializable;

/**
 *
 * @author johan
 */
public class Agua implements Serializable{
    private String marca;
    private String tipo;
    private String conteudo;
    private int quantidade;
    private double preco;
    
    
    public Agua(String marca, String tipo, String conteudo, int quantidade, double preco){
        this.marca=marca;
        this.tipo=tipo;
        this.conteudo=conteudo;
        this.quantidade=quantidade;
        this.preco=preco;
    }
    
    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getConteudo() {
        return conteudo;
    }

    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public String toString(){
        return "Marca: "+marca+"\nTipo: "+tipo+"\nConteudo: "+conteudo+"\nQauntidade: "+quantidade+"\nPreco: "+preco;
    }


}

