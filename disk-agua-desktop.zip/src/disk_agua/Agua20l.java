/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package disk_agua;

import java.io.Serializable;

/**
 *
 * @author johan
 */
public class Agua20l extends Agua implements Serializable{
    
    public Agua20l(String marca, String tipo, String conteudo, int quantidade, double preco){
        super(marca, tipo, conteudo, quantidade, preco);
    }
}
